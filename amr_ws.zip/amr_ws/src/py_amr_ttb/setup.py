from setuptools import find_packages, setup

package_name = 'py_amr_ttb'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name, ['launch/py_ttb_turn.launch.py', 'launch/py_lab_one_joystick.launch.py', 'launch/py_lab_one_controller.launch.py',]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='BrodyBrody41@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'ttb_turn = py_amr_ttb.ttb_turn:main',
            'lab_one_joystick = py_amr_ttb.lab_one_joystick:main',
            'lab_one_controller = py_amr_ttb.lab_one_controller:main',
            'lab_one_pid = py_amr_ttb.lab_one_pid:main',
        ],
    },
)
