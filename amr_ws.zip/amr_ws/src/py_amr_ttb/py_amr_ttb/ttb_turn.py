import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy

from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist

class TTBController(Node):

    def __init__(self):
        super().__init__('ttb_turn')
        # TODO: Update 'TTBXX/' topics with your team's robot number (e.g. TTB02 for robot 2)

        # setup publisher for Twist msg to /TTBXX/cmd_vel with buffer size = 10
        self.publisher_ = self.create_publisher(
            Twist,
            '/TTB10/cmd_vel',
            10
        )

        # setup subscriber to Imu msg from /TTBXX/imu with buffer size = 10
        qos_profile = QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT)
        self.subscriber_ = self.create_subscription(
            Imu,
            '/TTB10/imu',
            self.imu_callback,
            qos_profile
        )

        # setup controller to run at 10hz (period=.1s) and call method controller_callback
        timer_period = 0.1
        self.timer   = self.create_timer(timer_period, self.controller_callback)

        # when count >=30, stop moving vehicle
        self.count = 0

    def controller_callback(self):
        # create msg which makes TTB speed 0.1 m/s and angular velocity 0.4rad/s
        # if count >=30 (~3 seconds), stop moving

        msg = Twist()
        if self.count < 30:
            msg.linear.x  = 0.1
            msg.angular.z = 0.4
        else:
            msg.linear.x  = 0.0
            msg.angular.z = 0.0

        self.publisher_.publish(msg)
        self.count += 1

    def imu_callback(self, msg):
        # print angular velocity from imu message to console
        ang_vel = msg.angular_velocity.z
        self.get_logger().info(f'Angular velocity: {ang_vel:0.4f}')

def main(args=None):
    rclpy.init(args=args)

    ttb_controller = TTBController()

    rclpy.spin(ttb_controller)

    ttb_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
