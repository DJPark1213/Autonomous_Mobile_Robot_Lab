"""Behavioral tests for the continuous field, locked bypass and wall recovery."""

import math
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from py_amr_ttb.lab3.core import Config, LectureNavigator, process_scan
from py_amr_ttb.lab3.navigation import make_navigator
from py_amr_ttb.lab3.potential import PotentialNavigator
from py_amr_ttb.lab3.simulate import SCENARIOS, run_scenario


def hits(*points):
    """A healthy room scan with explicitly controlled nearest-hit geometry."""
    result = process_scan(np.full(360, 4.), -math.pi, 2*math.pi/360, .05, 12.)
    if points:
        result.points = np.asarray(points, dtype=float)
    return result


class PotentialTests(unittest.TestCase):
    """Verify outcomes that matter on the robot rather than formula copies."""

    def test_default_factory_and_explicit_lecture_baseline(self):
        self.assertIsInstance(make_navigator(Config()), PotentialNavigator)
        self.assertIsInstance(make_navigator(Config(planner='lecture')), LectureNavigator)
        for kwargs in ({'planner': 'other'}, {'repulsion_gain': 0.},
                       {'field_stall_timeout': -1.}, {'tangent_gain': math.nan}):
            with self.assertRaises(ValueError):
                Config(**kwargs)

    def test_clear_space_drives_directly_and_goal_behind_turns_without_reversing(self):
        nav = PotentialNavigator(Config())
        v, w = nav.step((0., 0., 0.), hits(), 0., .05)
        self.assertGreater(v, 0.)
        self.assertAlmostEqual(w, 0.)
        nav = PotentialNavigator(Config(goal_x=-1.5))
        v, w = nav.step((0., 0., 0.), hits(), 0., .05)
        self.assertEqual(v, 0.)
        self.assertNotEqual(w, 0.)

    def test_symmetric_front_box_chooses_side_and_moves_during_a_moderate_turn(self):
        nav = PotentialNavigator(Config())
        for i in range(6):
            v, w = nav.step((0., 0., 0.), hits((.65, 0.)), i*.05, .05)
        self.assertEqual(nav.wall_direction, -1)
        angle = math.atan2(nav.diagnostics['field_y'], nav.diagnostics['field_x'])
        self.assertGreater(angle, .55)
        self.assertGreater(v, 0.)
        self.assertGreater(w, 0.)

    def test_locked_side_does_not_flip_with_small_beam_noise(self):
        nav = PotentialNavigator(Config())
        for i in range(12):
            nav.step((0., 0., 0.), hits((.62, .01*(-1)**i)), i*.05, .05)
            if i == 0:
                chosen = nav.wall_direction
            self.assertEqual(nav.wall_direction, chosen)

    def test_right_override_produces_right_turn(self):
        nav = PotentialNavigator(Config(preferred_side='right'))
        for i in range(4):
            _, w = nav.step((0., 0., 0.), hits((.65, 0.)), i*.05, .05)
        self.assertEqual(nav.wall_direction, 1)
        self.assertLess(w, 0.)

    def stalled_controller(self):
        nav = PotentialNavigator(Config())
        for i in range(33):
            nav.step((0., 0., 0.), hits((.41, 0.)), i*.05, .05)
        self.assertIsNotNone(nav.fallback)
        self.assertEqual(nav.fallback_count, 1)
        self.assertEqual(nav.fallback_reason, 'NO_MOTION')
        return nav

    def test_actual_no_motion_hands_off_to_wall_controller(self):
        nav = self.stalled_controller()
        self.assertTrue(nav.state.startswith('FALLBACK_'))
        self.assertEqual(nav.fallback.wall_direction, nav.wall_direction)

    def test_wall_recovery_returns_to_field_and_keeps_same_goal(self):
        nav = self.stalled_controller()
        for i in range(4):
            nav.step((.2, 0., 0.), hits((-.41, 0.)), 1.7+i*.05, .05)
        self.assertIsNone(nav.fallback)
        self.assertEqual((nav.cfg.goal_x, nav.cfg.goal_y), (1.5, 0.))
        self.assertEqual(nav.wall_direction, 0)
        self.assertLess(nav.tangent_weight, 1e-9)
        self.assertEqual(nav.fallback_count, 1)

    def test_sensor_pause_does_not_count_as_field_stall(self):
        nav = PotentialNavigator(Config())
        nav.step((0., 0., 0.), hits((.65, 0.)), 0., .05)
        nav.pause('SENSOR_STOP')
        nav.step((0., 0., 0.), hits((.65, 0.)), 2., .05)
        self.assertIsNone(nav.fallback)

    def test_invalid_input_too_close_and_latched_completion_stop(self):
        nav = PotentialNavigator(Config())
        bad = process_scan([math.nan]*360, -math.pi, math.pi/180, .05, 12.)
        self.assertEqual(nav.step((0., 0., 0.), bad, 0., .05), (0., 0.))
        self.assertEqual(nav.step((0., 0., 0.), hits((.2, 0.)), .1, .05), (0., 0.))
        self.assertEqual(nav.state, 'TOO_CLOSE')
        self.assertEqual(nav.step((0., 0., 0.), hits(), .2, 1.), (0., 0.))
        self.assertEqual(nav.step((math.nan, 0., 0.), hits(), .3, .05), (0., 0.))
        self.assertEqual(nav.step((1.5, 0., 0.), hits(), .4, .05), (0., 0.))
        self.assertTrue(nav.done)
        self.assertEqual(nav.step((0., 0., 0.), hits(), .5, .05), (0., 0.))

    def test_duplicate_beams_do_not_scale_repulsive_force(self):
        a, b = PotentialNavigator(Config()), PotentialNavigator(Config())
        first = hits((.6, 0.), (4., 1.), (4., -1.))
        duplicate = hits(*np.repeat(first.points, 5, axis=0))
        self.assertEqual(a.step((0., 0., 0.), first, 0., .05),
                         b.step((0., 0., 0.), duplicate, 0., .05))

    def test_all_five_scenarios_complete_with_limits_and_body_clearance(self):
        cfg = Config()
        for name, boxes in SCENARIOS.items():
            with self.subTest(name=name):
                metric, rows = run_scenario(name, boxes, cfg)
                self.assertTrue(metric['reached'], metric)
                self.assertLessEqual(metric['goal_error_m'], cfg.goal_tolerance)
                self.assertGreater(metric['minimum_body_clearance_m'], cfg.safety_margin)
                self.assertTrue(all(0 <= r[4] <= cfg.max_linear for r in rows))
                self.assertTrue(all(abs(r[5]) <= cfg.max_angular for r in rows))
                increases = [b[4]-a[4] for a, b in zip(rows, rows[1:])]
                self.assertLessEqual(max(increases), cfg.acceleration*cfg.control_period+1e-9)

    def test_noisy_scan_and_right_bypass_reach_goal(self):
        cfg = Config(preferred_side='right')
        metric, rows = run_scenario('noisy_right', SCENARIOS['center_box'], cfg,
                                     scan_noise=.005, seed=7)
        self.assertTrue(metric['reached'], metric)
        self.assertLess(min(r[2] for r in rows), -.4)
        self.assertGreater(metric['minimum_body_clearance_m'], cfg.safety_margin)

    def test_feasible_goal_near_box_is_reached_and_blocked_goal_stops(self):
        feasible, _ = run_scenario('near_goal', [(.85, -.2, 1.1, .2)])
        self.assertTrue(feasible['reached'], feasible)
        cfg = Config(progress_timeout=8., max_runtime=25.)
        blocked, rows = run_scenario('goal_in_box', [(.8, -.3, 1.8, .3)], cfg, seconds=30.)
        self.assertFalse(blocked['reached'])
        self.assertIn(blocked['state'], ('NO_PROGRESS', 'TIME_LIMIT'))
        self.assertEqual(tuple(rows[-1][4:6]), (0., 0.))
        self.assertGreater(blocked['minimum_body_clearance_m'], cfg.safety_margin)


if __name__ == '__main__':
    unittest.main()
