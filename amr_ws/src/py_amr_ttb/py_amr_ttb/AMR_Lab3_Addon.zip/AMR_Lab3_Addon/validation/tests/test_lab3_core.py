"""Meaningful geometry, fault-stop and closed-loop tests without ROS."""

import math
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from py_amr_ttb.lab3.core import Config, LectureNavigator as Navigator, free_distances, guard_command, process_scan
from py_amr_ttb.lab3.follow import Follower
from py_amr_ttb.lab3.simulate import SCENARIOS, run_scenario
from py_amr_ttb.lab3.odometry import relative_pose


def scan(ranges=None, n=360, start=-math.pi, increment=None, **kwargs):
    """Make a full, known scan with optional injected returns."""
    return process_scan(np.full(n, 4.) if ranges is None else ranges, start,
                        2*math.pi/n if increment is None else increment, .05, 12., **kwargs)


def target_scan(x=1.2, y=0.):
    """Simulate a narrow visible target and distant room returns."""
    values = np.full(360, 4.)
    angles = np.linspace(-math.pi, math.pi, 360, endpoint=False)
    bearing = math.atan2(y, x)
    error = np.arctan2(np.sin(angles-bearing), np.cos(angles-bearing))
    values[np.abs(error) < .075] = math.hypot(x, y)
    return scan(values)


class ScanTests(unittest.TestCase):
    """Verify actual beam geometry, invalid inputs and extrinsics."""

    def test_different_sample_counts_start_angles_and_reversed_scan(self):
        for n in (360, 720, 1080):
            for start, sign in ((-math.pi, 1), (0., 1), (math.pi, -1)):
                values = np.full(n, 4.)
                angles = start + np.arange(n)*sign*2*math.pi/n
                index = np.argmin(np.abs(np.arctan2(np.sin(angles), np.cos(angles))))
                values[index] = .6
                result = scan(values, n, start, sign*2*math.pi/n)
                self.assertTrue(result.healthy, result.reason)
                self.assertAlmostEqual(result.sectors['F'], .6)

    def test_nan_inf_zero_negative_and_out_of_range(self):
        for value in (math.nan, math.inf, -math.inf, 0., -1., 15.):
            self.assertFalse(scan(np.full(360, value)).healthy)
        values = np.full(360, 4.)
        values[::3] = math.inf
        self.assertTrue(scan(values).healthy)
        self.assertTrue(np.all(np.isfinite(scan(values).points)))
        values[170:195] = math.nan
        self.assertFalse(scan(values).healthy)

    def test_partial_empty_and_bad_metadata(self):
        for ranges, amin, inc, lo, hi in (([], 0, .01, .05, 12),
                                         ([1.]*180, 0, math.pi/180, .05, 12),
                                         ([1.]*360, 0, 0, .05, 12),
                                         ([1.]*360, math.nan, .01, .05, 12),
                                         ([1.]*360, 0, .01, 12, .05)):
            self.assertFalse(process_scan(ranges, amin, inc, lo, hi).healthy)

    def test_translated_rotated_and_upside_down_laser(self):
        values = np.full(360, 4.)
        values[180] = 1.
        result = scan(values, transform=(.1, .2, math.pi/2))
        np.testing.assert_allclose(result.ordered[180], [.1, 1.2], atol=1e-12)
        result = scan(transform=(0., 0., 0.), angle_sign=-1.)
        np.testing.assert_allclose(result.ordered[270], [0., -4.], atol=1e-12)


class NavigationTests(unittest.TestCase):
    """Check stopping envelopes and end-to-end paths against exact obstacles."""

    def test_configuration_rejects_unsafe_or_nonfinite_values(self):
        for kwargs in ({'max_linear': .8}, {'sensor_timeout': .01},
                       {'robot_radius': .1}, {'safety_margin': .01},
                       {'goal_x': math.nan}, {'lookahead': .01},
                       {'preferred_side': 'wrong'}, {'follow_distance': .2},
                       {'wall_distance': .28}):
            with self.assertRaises(ValueError):
                Config(**kwargs)

    def test_capsule_includes_robot_width_not_only_front_ray(self):
        points = np.array([[.5, .2]])
        distance = free_distances(points, [0.], .27)[0]
        self.assertAlmostEqual(distance, .5-math.sqrt(.27**2-.2**2))
        self.assertEqual(free_distances(np.array([[-1., 0.]]), [0.], .27)[0], 4.)

    def test_guard_rejects_obstacle_inside_curved_stopping_sweep(self):
        cfg = Config(planner='lecture')
        obstacle = scan()
        obstacle.points = np.array([[.35, .08]])
        self.assertEqual(guard_command(.18, .7, obstacle, cfg, .18), (0., 0.))

    def test_goal_latched_and_invalid_scan_stops(self):
        nav = Navigator(Config())
        self.assertEqual(nav.step((0., 0., 0.), scan(np.full(360, math.nan)), 0, .05), (0., 0.))
        self.assertEqual(nav.step((1.5, 0., 0.), scan(), 1, .05), (0., 0.))
        self.assertTrue(nav.done)
        self.assertEqual(nav.step((0., 0., 0.), scan(), 2, .05), (0., 0.))

    def test_too_close_blocked_and_timing_gap(self):
        for values, expected in ((np.full(360, .2), 'TOO_CLOSE'),
                                 (np.full(360, .35), 'BLOCKED')):
            nav = Navigator(Config())
            self.assertEqual(nav.step((0., 0., 0.), scan(values), 1, .05), (0., 0.))
            self.assertEqual(nav.state, expected)
        nav = Navigator(Config())
        self.assertEqual(nav.step((0., 0., 0.), scan(), 1, 1.), (0., 0.))
        self.assertEqual(nav.state, 'TIMING_GAP')

    def test_unreachable_goal_progress_timeout_latches(self):
        nav = Navigator(Config(progress_timeout=1.))
        nav.step((0., 0., 0.), scan(np.full(360, .35)), 0, .05)
        self.assertEqual(nav.step((0., 0., 0.), scan(), 2., .05), (0., 0.))
        self.assertEqual(nav.state, 'NO_PROGRESS')

    def test_fixed_initial_frame_is_not_world_x_or_distance_travelled(self):
        start = (2., 3., math.pi/2)
        np.testing.assert_allclose(relative_pose(2., 4.5, math.pi/2, *start),
                                   [1.5, 0., 0.], atol=1e-12)

    def test_five_closed_loop_scenarios_and_command_limits(self):
        cfg = Config(planner='lecture')
        for name, boxes in SCENARIOS.items():
            with self.subTest(name=name):
                metrics, rows = run_scenario(name, boxes, cfg)
                self.assertTrue(metrics['reached'], metrics)
                self.assertLessEqual(metrics['goal_error_m'], cfg.goal_tolerance)
                self.assertGreater(metrics['minimum_body_clearance_m'], cfg.safety_margin)
                self.assertTrue(all(0 <= r[4] <= cfg.max_linear for r in rows))
                self.assertTrue(all(abs(r[5]) <= cfg.max_angular for r in rows))
                if boxes:
                    self.assertTrue(any(r[6].startswith('FOLLOW_WALL') for r in rows))

    def test_right_detour_and_noisy_lidar(self):
        cfg = Config(preferred_side='right', planner='lecture')
        metrics, rows = run_scenario('right_detour', SCENARIOS['center_box'], cfg, scan_noise=.005)
        self.assertTrue(metrics['reached'], metrics)
        self.assertLess(min(row[2] for row in rows), -.4)
        self.assertGreater(metrics['minimum_body_clearance_m'], cfg.safety_margin)

    def test_wander_avoids_front_box_without_completing_default_goal(self):
        from py_amr_ttb.lab3.simulate import raycast
        ranges, start, inc = raycast((.25, 0., 0.), SCENARIOS['center_box'])
        nav = Navigator(Config())
        v, w = nav.step((1.5, 0., 0.), process_scan(ranges, start, inc, .05, 12.), 0, .05, 'wander')
        self.assertFalse(nav.done)
        self.assertNotEqual(w, 0)


class LectureBehaviorTests(unittest.TestCase):
    """Verify lecture transitions, including all three independent leave guards."""

    def hits(self, *points):
        result = scan()
        result.points = np.array(points, dtype=float)
        return result

    def enter_wall(self):
        nav = Navigator(Config())
        nav.step((0., 0., 0.), self.hits((.41, 0.)), 0., .05)
        self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')
        self.assertEqual(nav.entry_distance, 1.5)
        return nav

    def test_dot_product_selects_tangent_toward_goal(self):
        for obstacle, expected in (((.38, .1), 'FOLLOW_WALL_CCW'),
                                   ((.38, -.1), 'FOLLOW_WALL_CW')):
            nav = Navigator(Config())
            nav.step((0., 0., 0.), self.hits(obstacle), 0., .05)
            self.assertEqual(nav.behavior, expected)

    def test_leaving_wall_requires_progress(self):
        nav = self.enter_wall()
        for i in range(1, 6):
            nav.step((0., 0., 0.), self.hits((-.41, 0.)), .05*i, .05)
        self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')

    def test_leaving_wall_requires_outward_normal_goal_alignment(self):
        nav = self.enter_wall()
        for i in range(1, 6):
            nav.step((.1, 0., 0.), self.hits((.41, 0.)), .05*i, .05)
        self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')

    def test_leaving_wall_checks_full_goal_corridor_for_other_obstacles(self):
        nav = self.enter_wall()
        for i in range(1, 6):
            nav.step((.1, 0., 0.), self.hits((-.41, 0.), (.8, 0.)), .05*i, .05)
        self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')

    def test_valid_wall_exit_is_debounced_and_retains_fixed_goal(self):
        nav = self.enter_wall()
        for i in (1, 2):
            nav.step((.1, 0., 0.), self.hits((-.41, 0.)), .05*i, .05)
            self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')
        nav.step((.1, 0., 0.), self.hits((-.41, 0.)), .15, .05)
        self.assertEqual(nav.behavior, 'GO_TO_GOAL')
        self.assertEqual((nav.cfg.goal_x, nav.cfg.goal_y), (1.5, 0.))

    def test_inside_boundary_enters_ao_then_recovers_same_wall_direction(self):
        nav = self.enter_wall()
        nav.step((0., 0., 0.), self.hits((.34, 0.)), .1, .05)
        self.assertEqual(nav.behavior, 'AVOID_OBSTACLE')
        nav.step((0., 0., 0.), self.hits((.405, 0.)), .15, .05)
        self.assertEqual(nav.behavior, 'FOLLOW_WALL_CW')

    def test_radial_correction_steers_away_when_close_and_toward_when_far(self):
        for distance, sign in ((.38, 1), (.43, -1)):
            nav = self.enter_wall()
            _, w = nav.step((0., 0., math.pi/2), self.hits((0., -distance)), .1, .05)
            self.assertGreater(sign*w, 0)


class FollowTests(unittest.TestCase):
    """Check acquisition, ego-motion compensation and target-loss stopping."""

    def acquire(self):
        follower = Follower(Config())
        for i in range(5):
            follower.observe(target_scan(), (0., 0., 0.), i*.1)
        self.assertTrue(follower.acquired)
        return follower

    def test_waits_for_target_and_requires_five_scan_confirmations(self):
        f = Follower(Config())
        self.assertEqual(f.step((0, 0, 0), scan(), 0., .05), (0., 0.))
        for i in range(4):
            f.observe(target_scan(), (0, 0, 0), .1*i)
            self.assertEqual(f.step((0, 0, 0), target_scan(), .1*i, .05), (0., 0.))
        f.observe(target_scan(), (0, 0, 0), .4)
        self.assertGreater(f.step((0, 0, 0), target_scan(), .4, .05)[0], 0.)

    def test_compensates_robot_motion_and_stops_at_follow_distance(self):
        f = self.acquire()
        f.observe(target_scan(.8), (.4, 0., 0.), .5)
        self.assertTrue(f.visible)
        self.assertEqual(f.step((.4, 0., 0.), target_scan(.8), .5, .05)[0], 0.)

    def test_lost_target_stops_immediately_then_requires_reset(self):
        f = self.acquire()
        f.observe(scan(), (0., 0., 0.), .5)
        self.assertEqual(f.step((0., 0., 0.), scan(), .5, .05), (0., 0.))
        f.observe(target_scan(), (0., 0., 0.), 1.3)
        self.assertEqual(f.step((0., 0., 0.), target_scan(), 1.3, .05), (0., 0.))
        self.assertTrue(f.lost_latched)

    def test_unrelated_distant_cluster_does_not_replace_target(self):
        f = self.acquire()
        f.observe(target_scan(.8, .8), (0., 0., 0.), .5)
        self.assertFalse(f.visible)
        self.assertEqual(f.step((0., 0., 0.), target_scan(.8, .8), .5, .05), (0., 0.))


if __name__ == '__main__':
    unittest.main()
