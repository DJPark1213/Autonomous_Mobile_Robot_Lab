"""Verify actual packaging, executable targets and launch argument wiring."""

import ast
import importlib
import os
from pathlib import Path
import runpy
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

import numpy as np

np.zeros(1).min()


def package_root():
    """Allow the delivered validation folder to test an existing workspace."""
    return Path(os.environ.get('LAB3_PACKAGE_ROOT', Path(__file__).resolve().parents[1])).expanduser().resolve()


class InstallationTests(unittest.TestCase):
    """Catch absent entry points, missing dependencies and wrong launch modes."""

    def test_manifest_installs_launches_and_importable_module_targets(self):
        package = package_root()
        captured = {}
        fake = ModuleType('setuptools')
        fake.find_packages = lambda **kwargs: ['py_amr_ttb.lab3']
        fake.setup = lambda **kwargs: captured.update(kwargs)
        previous = Path.cwd()
        try:
            os.chdir(package)
            with patch.dict(sys.modules, {'setuptools': fake}):
                runpy.run_path(str(package / 'setup.py'))
        finally:
            os.chdir(previous)
        for target in ('node', 'plot', 'simulate'):
            tree = ast.parse((package/'py_amr_ttb'/'lab3'/f'{target}.py').read_text())
            self.assertIn('main', [n.name for n in tree.body if isinstance(n, ast.FunctionDef)])
        installed = {Path(p).name for dest, paths in captured['data_files'] for p in paths}
        for name in ('go_to_goal', 'follow_me', 'wander'):
            self.assertIn(f'lab3_{name}.launch.py', installed)
        deps = {item.text for item in ET.parse(package/'package.xml').getroot()
                if item.tag.endswith('depend')}
        self.assertTrue({'tf2_ros', 'sensor_msgs', 'nav_msgs', 'std_srvs', 'python3-numpy',
                         'launch'} <= deps)

    def test_launches_use_circle_module_pattern_and_internal_tf_mapping(self):
        package = package_root()
        sys.path.insert(0, str(package))
        modules = {name: ModuleType(name) for name in (
            'launch', 'launch.actions', 'launch.substitutions')}
        modules['launch'].LaunchDescription = lambda items: items
        modules['launch.actions'].DeclareLaunchArgument = lambda name, **kw: NS(name=name, **kw)
        modules['launch.actions'].ExecuteProcess = lambda **kw: NS(**kw)
        modules['launch.substitutions'].LaunchConfiguration = lambda name: NS(config=name)
        with patch.dict(sys.modules, modules):
            # Use the real helper with fake launch data containers only.
            importlib.import_module('py_amr_ttb.lab3.launch_support')
            for filename, mode in (('go_to_goal', 'goal'), ('follow_me', 'follow'), ('wander', 'wander')):
                launch = runpy.run_path(str(package/'launch'/f'lab3_{filename}.launch.py'))
                description = launch['generate_launch_description']()
                defaults = {a.name: a.default_value for a in description[:-1]}
                self.assertEqual(defaults['robot_namespace'], '/TTB10')
                self.assertTrue({'base_frame', 'robot_namespace', 'max_linear', 'log_dir'} <= defaults.keys())
                self.assertTrue({'namespace', 'timestamp_policy', 'scan_topic', 'tf_topic'}.isdisjoint(defaults))
                process = description[-1]
                self.assertTrue(process.emulate_tty)
                self.assertEqual(process.cmd[:4], [sys.executable, '-m', 'py_amr_ttb.lab3.node', '--ros-args'])
                def resolve(value):
                    if isinstance(value, list):
                        return ''.join(resolve(item) for item in value)
                    return defaults[value.config] if hasattr(value, 'config') else value
                command = [resolve(arg) for arg in process.cmd]
                self.assertIn('mode:='+mode, command)
                self.assertIn('robot_namespace:=/TTB10', command)
                self.assertIn('goal_x:=1.5', command)
                self.assertIn('allow_positive_inf:=true', command)
                self.assertIn('/tf:=/TTB10/tf', command)
                self.assertIn('/tf_static:=/TTB10/tf_static', command)
                self.assertFalse(any('__ns:=' in arg or '__node:=' in arg for arg in command))


if __name__ == '__main__':
    unittest.main()
