"""Verify actual packaging, executable targets and launch argument wiring."""

import ast
import importlib
import os
from pathlib import Path
import runpy
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

import numpy as np

np.zeros(1).min()


def package_root():
    """Allow the delivered validation folder to test an existing workspace."""
    return Path(os.environ.get('LAB3_PACKAGE_ROOT', Path(__file__).resolve().parents[1])).expanduser().resolve()


class InstallationTests(unittest.TestCase):
    """Catch absent entry points, missing dependencies and wrong launch modes."""

    def test_manifest_contains_lab3_entrypoints_and_launches(self):
        package = package_root()
        captured = {}
        fake = ModuleType('setuptools')
        fake.find_packages = lambda **kwargs: ['py_amr_ttb.lab3']
        fake.setup = lambda **kwargs: captured.update(kwargs)
        previous = Path.cwd()
        try:
            os.chdir(package)
            with patch.dict(sys.modules, {'setuptools': fake}):
                runpy.run_path(str(package / 'setup.py'))
        finally:
            os.chdir(previous)
        scripts = captured['entry_points']['console_scripts']
        for entry, target in (('controller', 'node'), ('plot', 'plot'), ('simulate', 'simulate')):
            self.assertIn(f'lab3_{entry} = py_amr_ttb.lab3.{target}:main', scripts)
            tree = ast.parse((package/'py_amr_ttb'/'lab3'/f'{target}.py').read_text())
            self.assertIn('main', [n.name for n in tree.body if isinstance(n, ast.FunctionDef)])
        installed = {Path(p).name for dest, paths in captured['data_files'] for p in paths}
        for name in ('go_to_goal', 'follow_me', 'wander'):
            self.assertIn(f'lab3_{name}.launch.py', installed)
        deps = {item.text for item in ET.parse(package/'package.xml').getroot()
                if item.tag.endswith('depend')}
        self.assertTrue({'tf2_ros', 'sensor_msgs', 'nav_msgs', 'std_srvs', 'python3-numpy',
                         'launch', 'launch_ros'} <= deps)

    def test_launches_expose_namespace_frames_modes_and_typed_parameters(self):
        package = package_root()
        sys.path.insert(0, str(package))
        modules = {name: ModuleType(name) for name in (
            'launch', 'launch.actions', 'launch.substitutions', 'launch_ros',
            'launch_ros.actions', 'launch_ros.parameter_descriptions')}
        modules['launch'].LaunchDescription = lambda items: items
        modules['launch.actions'].DeclareLaunchArgument = lambda name, **kw: NS(name=name, **kw)
        modules['launch.substitutions'].LaunchConfiguration = lambda name: NS(config=name)
        modules['launch_ros.actions'].Node = lambda **kw: NS(**kw)
        modules['launch_ros.parameter_descriptions'].ParameterValue = lambda value, **kw: NS(value=value, **kw)
        with patch.dict(sys.modules, modules):
            # Use the real helper with fake launch data containers only.
            importlib.import_module('py_amr_ttb.lab3.launch_support')
            for filename, mode in (('go_to_goal', 'goal'), ('follow_me', 'follow'), ('wander', 'wander')):
                launch = runpy.run_path(str(package/'launch'/f'lab3_{filename}.launch.py'))
                description = launch['generate_launch_description']()
                node = description[-1]
                self.assertEqual(node.namespace.config, 'namespace')
                self.assertEqual(node.parameters[0]['mode'], mode)
                self.assertEqual(node.parameters[0]['goal_x'].value_type, float)
                self.assertEqual(node.parameters[0]['allow_positive_inf'].value_type, bool)
                self.assertEqual(node.parameters[0]['timestamp_policy'].value_type, str)
                self.assertEqual(node.parameters[0]['timestamp_policy'].value.config, 'timestamp_policy')
                arguments = {a.name for a in description[:-1]}
                self.assertTrue({'base_frame', 'namespace', 'scan_topic', 'tf_topic',
                                 'max_linear', 'preferred_side', 'log_dir', 'timestamp_policy'} <= arguments)
                defaults = {a.name: a.default_value for a in description[:-1]}
                self.assertEqual(defaults['timestamp_policy'], 'receipt')


if __name__ == '__main__':
    unittest.main()
