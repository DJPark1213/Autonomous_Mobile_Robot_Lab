"""Exercise the actual ROS adapter with message/clock/TF doubles, not ROS transport."""

import importlib
import csv
import math
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import patch

import numpy as np

# Load NumPy before a scoped sys.modules patch; NumPy must never be reimported.
np.zeros(1).min()


class Twist:
    """Minimal command message double."""

    def __init__(self):
        self.linear, self.angular = NS(x=0.), NS(z=0.)


class Time:
    """Simulated ROS timestamp."""

    def __init__(self, nanoseconds=0):
        self.nanoseconds = nanoseconds

    @classmethod
    def from_msg(cls, stamp):
        return cls(stamp.sec*10**9 + stamp.nanosec)


class FakeNode:
    """In-memory node I/O with an explicitly controlled ROS clock."""

    overrides = {'log_dir': ''}
    now_ns = 10*10**9

    def __init__(self, name):
        self.outputs = {}
        self.subs = {}

    def declare_parameter(self, name, default):
        return NS(value=self.overrides.get(name, default))

    def create_publisher(self, kind, topic, qos):
        self.outputs[topic] = []
        return NS(publish=self.outputs[topic].append)

    def create_subscription(self, kind, topic, callback, qos):
        self.subs[topic] = callback
        return callback

    def create_service(self, kind, topic, callback):
        return callback

    def create_timer(self, period, callback):
        return NS(cancel=lambda: None)

    def get_logger(self):
        return NS(info=lambda text: None, warning=lambda text: None)

    def get_clock(self):
        return NS(now=lambda: Time(self.now_ns))


class TFError(Exception):
    """Missing-transform double."""


class Buffer:
    """TF lookup succeeds only when the test explicitly supplies a transform."""

    def __init__(self):
        self.result = None

    def lookup_transform(self, *args):
        if self.result is None:
            raise TFError('missing transform')
        return self.result


def header(frame='base_link', time_s=10.):
    """Create a stamped header."""
    ns = round(time_s*1e9)
    return NS(frame_id=frame, stamp=NS(sec=ns//10**9, nanosec=ns % 10**9))


def odom(x=0., y=0., yaw=0., time_s=10.):
    """Create a valid planar pose."""
    return NS(header=header('odom', time_s),
              pose=NS(pose=NS(position=NS(x=x, y=y),
                              orientation=NS(x=0., y=0., z=math.sin(yaw/2), w=math.cos(yaw/2)))))


def laser(frame='base_link', time_s=10., value=4.):
    """Create a complete scan."""
    return NS(header=header(frame, time_s), ranges=[value]*360,
              angle_min=-math.pi, angle_increment=2*math.pi/360,
              range_min=.05, range_max=12.)


class NodeTests(unittest.TestCase):
    """Check adapter faults, timestamp replay, stop/reset and fresh recovery."""

    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        names = ('rclpy', 'rclpy.node', 'rclpy.qos', 'rclpy.signals', 'rclpy.time',
                 'geometry_msgs', 'geometry_msgs.msg', 'nav_msgs', 'nav_msgs.msg',
                 'sensor_msgs', 'sensor_msgs.msg', 'std_msgs', 'std_msgs.msg',
                 'std_srvs', 'std_srvs.srv', 'tf2_ros')
        modules = {name: ModuleType(name) for name in names}
        modules['rclpy.node'].Node = FakeNode
        modules['rclpy.qos'].qos_profile_sensor_data = object()
        modules['rclpy.qos'].QoSProfile = NS
        modules['rclpy.qos'].ReliabilityPolicy = NS(BEST_EFFORT=1)
        modules['rclpy.signals'].SignalHandlerOptions = NS(NO=0)
        modules['rclpy.time'].Time = Time
        modules['geometry_msgs.msg'].Twist = Twist
        modules['nav_msgs.msg'].Odometry = object
        modules['sensor_msgs.msg'].LaserScan = object
        modules['std_msgs.msg'].String = NS
        modules['std_srvs.srv'].Trigger = object
        modules['tf2_ros'].Buffer = Buffer
        modules['tf2_ros'].TransformException = TFError
        modules['tf2_ros'].TransformListener = lambda *args: None
        with patch.dict(sys.modules, modules):
            cls.module = importlib.import_module('py_amr_ttb.lab3.node')

    def setUp(self):
        FakeNode.overrides = {'log_dir': ''}
        FakeNode.now_ns = 10*10**9
        self.clock = patch('time.monotonic', return_value=10.)
        self.clock_mock = self.clock.start()
        self.addCleanup(self.clock.stop)
        self.node = self.module.Lab3Controller()

    def advance(self, t):
        self.clock_mock.return_value = t
        FakeNode.now_ns = round(t*1e9)

    def command(self):
        self.node.tick()
        cmd = self.node.outputs['cmd_vel'][-1]
        return cmd.linear.x, cmd.angular.z

    def test_missing_sensors_stop_and_both_fresh_sensors_allow_motion(self):
        self.assertEqual(self.command(), (0., 0.))
        self.node.odom_callback(odom())
        self.advance(10.05)
        self.assertEqual(self.command(), (0., 0.))
        self.node.scan_callback(laser(time_s=10.05))
        self.advance(10.1)
        self.assertGreater(self.command()[0], 0.)

    def test_scan_and_odom_each_have_independent_watchdogs(self):
        for stale in ('scan', 'odom'):
            with self.subTest(stale=stale):
                self.setUp_fresh()
                self.advance(10.5)
                if stale == 'scan':
                    self.node.odom_callback(odom(time_s=10.5))
                else:
                    self.node.scan_callback(laser(time_s=10.5))
                self.assertEqual(self.command(), (0., 0.))

    def setUp_fresh(self):
        self.advance(10.)
        self.node = self.module.Lab3Controller()
        self.node.odom_callback(odom())
        self.node.scan_callback(laser())

    def test_missing_tf_stops_and_valid_tf_recovers(self):
        self.node.odom_callback(odom())
        self.node.scan_callback(laser('laser_frame'))
        self.assertEqual(self.command(), (0., 0.))
        self.node.tf_buffer.result = NS(transform=NS(translation=NS(x=.05, y=0.),
                                                    rotation=NS(x=0., y=0., z=0., w=1.)))
        self.advance(10.1)
        self.node.scan_callback(laser('laser_frame', time_s=10.1))
        self.assertGreater(self.command()[0], 0.)

    def test_stale_future_zero_and_replayed_timestamps_stop(self):
        for timestamp in (0., 8., 12.):
            self.setUp_fresh()
            self.node.scan_callback(laser(time_s=timestamp))
            self.assertEqual(self.command(), (0., 0.))
        self.setUp_fresh()
        self.node.scan_callback(laser())
        self.assertEqual(self.command(), (0., 0.))

    def test_invalid_scan_never_reuses_previous_valid_scan(self):
        self.setUp_fresh()
        self.advance(10.1)
        self.node.scan_callback(laser(time_s=10.1, value=math.nan))
        self.assertEqual(self.command(), (0., 0.))

    def test_invalid_odom_and_frame_change_stop(self):
        self.setUp_fresh()
        self.advance(10.1)
        self.node.odom_callback(odom(x=math.nan, time_s=10.1))
        self.assertEqual(self.command(), (0., 0.))
        self.setUp_fresh()
        self.advance(10.1)
        message = odom(time_s=10.1)
        message.header.frame_id = 'other_odom'
        self.node.odom_callback(message)
        self.assertEqual(self.command(), (0., 0.))
        self.assertIn('FRAME_CHANGED', self.node.status)

    def test_pose_jump_is_latched(self):
        self.setUp_fresh()
        self.advance(10.1)
        self.node.odom_callback(odom(x=2., time_s=10.1))
        self.assertEqual(self.command(), (0., 0.))
        self.assertIn('JUMP', self.node.status)

    def test_stop_and_reset_capture_new_start_pose(self):
        self.setUp_fresh()
        response = self.node.stop_callback(None, NS())
        self.assertTrue(response.success)
        self.assertEqual(self.command(), (0., 0.))
        self.node.reset_callback(None, NS())
        self.assertEqual(self.command(), (0., 0.))
        self.advance(10.1)
        self.node.odom_callback(odom(2., 3., math.pi/2, 10.1))
        self.node.scan_callback(laser(time_s=10.1))
        self.assertEqual(self.node.pose, (0., 0., 0.))
        self.assertGreater(self.command()[0], 0.)

    def test_shutdown_sends_zero(self):
        self.setUp_fresh()
        self.node.close()
        last = self.node.outputs['cmd_vel'][-1]
        self.assertEqual((last.linear.x, last.angular.z), (0., 0.))

    def test_csv_records_sent_commands_and_plot_reads_it(self):
        from py_amr_ttb.lab3.plot import main as plot_main
        with tempfile.TemporaryDirectory() as directory:
            FakeNode.overrides = {'log_dir': directory}
            self.node = self.module.Lab3Controller()
            self.node.odom_callback(odom())
            self.node.scan_callback(laser())
            velocity = self.command()
            self.node.close()
            path = next(Path(directory).glob('*.csv'))
            with path.open() as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(float(rows[0]['v_m_s']), velocity[0])
            self.assertEqual(float(rows[-1]['v_m_s']), 0.)
            self.assertEqual(float(rows[-1]['w_rad_s']), 0.)
            plot_main([str(path)])
            self.assertGreater(path.with_suffix('.png').stat().st_size, 1000)


if __name__ == '__main__':
    unittest.main()
