# Lab 3 增量包

主要代码在一个 `lab3/` 文件夹，对应启动文件在 `launch/`。把这两部分加入你现有的 `py_amr_ttb` ROS 2 包即可。

默认算法为 **势场连续引导 + 固定切向绕行 + 沿墙脱困**，对应 Lecture 6 的人工势场和 Lecture 5 的沿边界控制。旧版沿墙状态机保留为 `planner:=lecture`，便于在同一机器人上比较。

本版按你已经能运行的 **Lab 2 circle** 接入 ROS：完整话题名、同一个 `qos_profile_sensor_data`、本机接收时间检查、`ExecuteProcess + python -m` 启动。默认机器人为 `/TTB10`，启动只需一条不带参数的 launch 命令。

已经安装过上一版时，覆盖整个内层 `lab3/` 文件夹，并复制 `launch/` 下的三个启动文件。此次代码改动在 `lab3/core.py`、`lab3/node.py`、`lab3/launch_support.py`；Lab 2 文件不需要修改。

## 1. 放到哪里

| 本包内容 | 复制到原工程 |
| --- | --- |
| 整个 `lab3/` 文件夹 | `~/amr_ws/src/py_amr_ttb/py_amr_ttb/lab3/` |
| `launch/` 中的三个文件 | `~/amr_ws/src/py_amr_ttb/launch/` |

注意内外有两层 `py_amr_ttb`：外层包含 `setup.py`，内层是 Python 包。`lab3` 放在**内层**，`launch` 放在**外层**。

例如在解压后的 `AMR_Lab3_Addon/` 目录中运行：

```bash
cp -r lab3 ~/amr_ws/src/py_amr_ttb/py_amr_ttb/
cp launch/lab3_*.launch.py ~/amr_ws/src/py_amr_ttb/launch/
```

如果已经装过之前版本，更新已有 `lab3/` 中的文件。当前文件夹包含自身的位姿工具，不依赖 Lab 1/2 的行为代码。

## 2. setup.py

与你的 circle 一样，launch 直接执行 `python -m py_amr_ttb.lab3.node`，**不需要新增 console_scripts 入口**。之前已经添加的 lab3 入口可以保留。

你的原工程已使用 `find_packages(...)` 和 `glob('launch/*.launch.py')`，会自动安装 `lab3` 子包和启动文件。

## 3. 修改 package.xml

原工程已有 rclpy、geometry_msgs、sensor_msgs、nav_msgs 和 std_msgs。确认还包含以下依赖；缺少才添加，避免重复：

```xml
<depend>tf2_ros</depend>
<depend>std_srvs</depend>
<exec_depend>launch</exec_depend>
<exec_depend>python3-numpy</exec_depend>
<exec_depend>python3-matplotlib</exec_depend>
```

## 4. 编译和运行

下面沿用你截图中的构建位置 `~/amr_ws/src/install/`。构建和 source 使用同一套目录，避免同时混用另一个 `~/amr_ws/install/`。

```bash
cd ~/amr_ws/src
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-select py_amr_ttb
source install/setup.bash
ros2 launch py_amr_ttb lab3_go_to_goal.launch.py
```

这条 launch 默认连接 TTB10，执行绕箱后到启动时正前方 1.5 m 的任务。无需输入 `namespace`、`timestamp_policy` 或各个 topic 参数。

启动日志会显示实际的 `odom=/TTB10/odom, scan=/TTB10/scan, cmd_vel=/TTB10/cmd_vel`。收到里程计时会打印 `Starting pose captured`，收到有效雷达并完成安装坐标变换后打印 `First valid laser scan received`。

默认 `planner:=potential`；同场景对照旧版：

```bash
ros2 launch py_amr_ttb lab3_go_to_goal.launch.py planner:=lecture
```

首次地面试跑可设置 `max_linear:=0.10`。正常默认上限仍为 0.18 m/s 和 0.70 rad/s；没有通过提高这两个上限取得仿真时间改善。

选做 Follow-me（先关闭其他运动节点）：

```bash
ros2 launch py_amr_ttb lab3_follow_me.launch.py
```

局部障碍赛练习模式，没有终点识别：

```bash
ros2 launch py_amr_ttb lab3_wander.launch.py
```

## 5. 接口与接收检查

| 接口 | 默认完整名称 |
| --- | --- |
| 里程计订阅 | `/TTB10/odom`，Odometry |
| 雷达订阅 | `/TTB10/scan`，LaserScan |
| 速度发布 | `/TTB10/cmd_vel`，Twist |
| 节点名称 | `/lab3_controller`，与 circle 一样不加机器人 namespace |
| 状态话题 | `/TTB10/lab3/status` |

`robot_namespace` 是机器人话题前缀，默认 `/TTB10`，不作为节点 namespace。换车时可用 `robot_namespace:=/TTB04`；参数规则与你的 circle 一样。

底盘、雷达及机器人状态发布程序应已运行。这些 launch 只启动 Lab 3 控制器；有效数据到齐后会自动开始运动。

里程计和雷达都使用 circle 的 `qos_profile_sensor_data`。与 circle 一样，只用本机 `time.monotonic()` 检查接收间隔；任一路超过 0.4 秒没有新的有效数据就停车，不用电脑日期减机器人消息日期，不要求两台设备同步系统日期。旧版的 `timestamp_policy` 参数已移除。

Lab 3 额外需要把雷达点转换到底盘坐标系。launch 内部已将 TF 监听映射到 `/TTB10/tf` 和 `/TTB10/tf_static`，不需要手动输入映射参数。仍按扫描时刻查询 `base_link` 与雷达 frame 的变换，缺失时停车；不会假设两者重合。雷达与对应 TF 发布者内部的时间来源仍需相容。

接收间隔检查无法直接估计网络延迟，也不通过消息时间戳识别旧包或回放。有限测距、扫描覆盖、TF、位姿跳变和车体碰撞保护继续保留。

`SENSOR_STOP` 会显示等待哪个传感器、TF 缺失或断流等原因；错误变化时日志也会更新。完整状态可读取：

```bash
ros2 topic echo /TTB10/lab3/status --once
```

若实际底盘使用 TwistStamped，需要相应消息适配。检查 `ros2 topic info /TTB10/cmd_vel -v`；不能通过重命名 topic 替代消息类型转换。

启动后数据有效就会自动开始；到点后持续停车。`Ctrl+C` 退出。也可以主动锁定停车：

```bash
ros2 service call /TTB10/lab3/stop std_srvs/srv/Trigger '{}'
```

重新放好机器人后重启节点，可获得独立 CSV。显式 reset 会以接下来的第一条里程计**重新定义起点和新目标**：

```bash
ros2 service call /TTB10/lab3/reset std_srvs/srv/Trigger '{}'
```

## 6. 算法与常用参数

新控制器用目标吸引、障碍排斥和固定方向的切向量合成运动方向，平滑转弯。检测到停滞、目标距离长期没有改善或场幅值过低时，调用旧版沿墙控制器脱困。方向偏到后方或碰撞检查不通过时仍会停车/原地转向。

| 参数 | 默认值 | 含义 |
| --- | ---: | --- |
| `planner` | `potential` | 新版；`lecture` 为旧版对照 |
| `goal_x`, `goal_y` | `1.5`, `0.0` | 启动坐标系中的固定目标，米 |
| `goal_tolerance` | `0.06` | 到点误差容差，米 |
| `max_linear`, `max_angular` | `0.18`, `0.70` | 速度上限 |
| `robot_radius`, `safety_margin` | `0.19`, `0.08` | 车体等效半径与额外余量，米 |
| `preferred_side` | `auto` | 自动选择；可设 `left` 或 `right` |
| `field_influence` | `0.50` | 排斥作用范围，从膨胀后的车体边界计量，米 |
| `repulsion_gain` | `0.002` | 排斥强度 |
| `tangent_gain` | `4.0` | 切向引导强度 |
| `field_stall_timeout` | `1.5` | 位移不足时进入沿墙脱困的秒数 |
| `sensor_timeout` | `0.4` | 未收到新有效数据时停车的等待上限，秒 |
| `robot_namespace` | `/TTB10` | 与 circle 相同的机器人话题前缀 |

节点还检查完整扫描、无效距离、TF、里程计跳变和车体停止轨迹。默认尺寸、余量和制动参数仍须在实际 TurtleBot 上确认。

完整公式和所有课程讲义对应见 [lab3/README.md](lab3/README.md)。切向量、平滑与脱困组合是工程改进，整个场不等同于纯 APF 的负梯度。

## 7. 仿真结果与适用范围

在相同速度、车体余量及 10 Hz 雷达条件下：

| 单箱场景 | 旧版时间 | 新版时间 | 时间缩短 |
| --- | ---: | ---: | ---: |
| 居中纸箱 | 16.50 s | 14.05 s | 14.8% |
| 偏左纸箱 | 18.75 s | 16.20 s | 13.6% |
| 偏右纸箱 | 14.50 s | 12.45 s | 14.1% |
| 较宽纸箱 | 18.75 s | 16.20 s | 13.6% |

这四个场景中新版最小车体净空约 0.19–0.24 m。额外较小、较近、较远纸箱也到点；对这 7 个单箱场景各加入 3 个种子的 5 mm 测距噪声，两版各 21/21 次到点。

**交错双障碍挑战中两版都没有到点，而是以 NO_PROGRESS 停车。** 因此本版适合当前单纸箱任务，不保证通过任意复杂赛道。完整结果、失败场景、参数与轨迹见 [validation/comparison/REPORT.md](validation/comparison/REPORT.md)。

这些是理想二维仿真，不是实测速度。当前环境没有 ROS 2 或实体机器人；colcon、DDS/QoS、实际 TF、制动和地面试跑仍需在实验室完成。

## 8. 数据与复查

已用原始上传的 Lab 2 包加上本增量包和上述安装修改，完成 57 项离线检查，全部通过。验证了包发现、启动文件安装、两种控制器、停车保护、跟随与记录功能；ROS 接口使用替身。检查覆盖完整话题名和 circle QoS、模块启动命令和内部 TF 映射、机器人日期落后 91 天、断流、扫描时刻 TF 查询和停车原因更新。安装验证使用原始 setup.py，没有添加任何 lab3 console_scripts。

实机运行会把 CSV 保存到 `~/amr_lab3_runs/`，包含实际发布的速度、里程计轨迹、状态、势场向量和脱困次数。画图：

```bash
python3 -m py_amr_ttb.lab3.plot ~/amr_lab3_runs/实际文件名.csv
```

在已经安装新模块的 workspace 环境中复现仿真：

```bash
python3 -m py_amr_ttb.lab3.simulate --planner potential --output potential_run
python3 -m py_amr_ttb.lab3.simulate --planner lecture --output lecture_run
python3 -m py_amr_ttb.lab3.benchmark --output comparison_run
```

在本增量包解压目录运行离线检查（只需 NumPy、Matplotlib，ROS 接口使用替身）：

```bash
LAB3_PACKAGE_ROOT="$HOME/amr_ws/src/py_amr_ttb" \
PYTHONPATH="$HOME/amr_ws/src/py_amr_ttb${PYTHONPATH:+:$PYTHONPATH}" \
python3 -m unittest discover -s validation/tests -p 'test_lab3*.py' -v
```

## 9. 代码分工

| 文件 | 作用 |
| --- | --- |
| `lab3/node.py` | circle 风格的完整话题、接收检查、TF、停止服务、CSV |
| `lab3/potential.py` | 新版势场、固定绕行侧、停滞与脱困交接 |
| `lab3/core.py` | 配置、雷达处理、车体保护、旧版沿墙对照 |
| `lab3/navigation.py` | 按 `planner` 参数选择控制器 |
| `lab3/odometry.py` | 独立位姿工具 |
| `lab3/follow.py` | 选做点簇跟随 |
| `lab3/launch_support.py` | 三个 launch 共用的参数定义 |
| `lab3/simulate.py`、`benchmark.py` | 仿真与同条件比较 |
| `lab3/plot.py` | 运行 CSV 绘图 |
