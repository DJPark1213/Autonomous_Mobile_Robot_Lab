"""Shared launch construction for independently selected Lab 3 modes."""

from dataclasses import fields

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

from .core import Config


def launch_description(mode):
    """Expose configuration and topic/frame overrides without editing source."""
    defaults = Config()
    args = [DeclareLaunchArgument('namespace', default_value='TTB10'),
            DeclareLaunchArgument('base_frame', default_value='base_link'),
            DeclareLaunchArgument('log_dir', default_value='~/amr_lab3_runs'),
            DeclareLaunchArgument('timestamp_policy', default_value='receipt'),
            DeclareLaunchArgument('use_sim_time', default_value='false')]
    for topic in ('scan', 'odom', 'cmd_vel', 'tf', 'tf_static'):
        args.append(DeclareLaunchArgument(topic + '_topic', default_value=topic))
    parameters = {'mode': mode,
                  'base_frame': ParameterValue(LaunchConfiguration('base_frame'), value_type=str),
                  'log_dir': ParameterValue(LaunchConfiguration('log_dir'), value_type=str),
                  'timestamp_policy': ParameterValue(LaunchConfiguration('timestamp_policy'), value_type=str),
                  'use_sim_time': ParameterValue(LaunchConfiguration('use_sim_time'), value_type=bool)}
    for field in fields(Config):
        value = getattr(defaults, field.name)
        default = str(value).lower() if isinstance(value, bool) else str(value)
        args.append(DeclareLaunchArgument(field.name, default_value=default))
        parameters[field.name] = ParameterValue(LaunchConfiguration(field.name), value_type=type(value))
    return LaunchDescription([*args, Node(
        package='py_amr_ttb', executable='lab3_controller', name='lab3_controller',
        namespace=LaunchConfiguration('namespace'), output='screen', parameters=[parameters],
        remappings=[(topic, LaunchConfiguration(topic + '_topic'))
                    for topic in ('scan', 'odom', 'cmd_vel')]
        + [('/tf', LaunchConfiguration('tf_topic')),
           ('/tf_static', LaunchConfiguration('tf_static_topic'))],
    )])
