"""Defaults owned by the circle task; no edits to shared LabConfig are needed."""

from py_amr_ttb.lab_config import LabConfig


class CircleConfig(LabConfig):
    """Reuse existing robot topics/limits and add only circle-specific defaults."""

    CIRCLE_RADIUS = 0.75
    CIRCLE_SPEED = 0.12
    CIRCLE_LOOKAHEAD = 0.30
    CIRCLE_LAPS = 1
    CIRCLE_DIRECTION = 1
    CIRCLE_FINISH_YAW_TOLERANCE = 0.25
    CIRCLE_MAX_RADIAL_ERROR = 0.35
