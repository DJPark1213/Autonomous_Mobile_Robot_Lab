#!/usr/bin/env bash
set -euo pipefail
bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target_dir="${1:-$HOME/amr_ws/src/py_amr_ttb/py_amr_ttb/lab3}"
for name in core.py potential.py node.py; do
  test -f "$target_dir/$name" || { echo "Missing expected file: $target_dir/$name" >&2; exit 1; }
done
backup_dir="$(mktemp -d "$target_dir/backup_coordinated_XXXXXXXX")"
for name in core.py potential.py node.py; do
  cp -p "$target_dir/$name" "$backup_dir/$name"
  cp "$bundle_dir/lab3/$name" "$target_dir/$name"
done
printf 'Installed 3 files. Backup: %s\n' "$backup_dir"
printf 'Rebuild and source the workspace before launching.\n'
