import unittest,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'validation'))
from py_amr_ttb.lab3.core import Config,process_scan
from py_amr_ttb.lab3.potential import PotentialNavigator
from py_amr_ttb.lab3.simulate import raycast

def scan(boxes=()):
 r,a,i=raycast((0,0,0),boxes)
 return process_scan(r,a,i,.05,12.)
class Regression(unittest.TestCase):
 def test_residual_motion_cannot_release_brake(self):
  n=PotentialNavigator(Config())
  for k in range(30):
   n.set_motion_feedback(.04,0,k*.05)
   self.assertEqual(n.step((0,0,0),scan(),k*.05,.05),(0.,0.))
  self.assertEqual(n.phase,'BRAKE')
 def test_reused_scan_is_not_three_confirmations(self):
  n=PotentialNavigator(Config());s=scan()
  for k in range(30):
   n.set_motion_feedback(0,0,k*.05)
   self.assertEqual(n.step((0,0,0),s,k*.05,.05),(0.,0.))
  self.assertEqual(n.phase,'ALIGN')
 def test_fresh_scans_release_and_no_straight_left_bias(self):
  n=PotentialNavigator(Config())
  for k in range(25):
   n.set_motion_feedback(0,0,k*.05)
   v,w=n.step((0,0,0),scan(),k*.05,.05)
   self.assertAlmostEqual(w,0)
  self.assertGreater(v,0)
 def test_stale_motion_feedback_stops(self):
  n=PotentialNavigator(Config());n.set_motion_feedback(0,0,0)
  self.assertEqual(n.step((0,0,0),scan(),1,.05),(0.,0.))
  self.assertEqual(n.state,'MOTION_FEEDBACK_STALE')
 def test_footprint_intrusion_stops(self):
  n=PotentialNavigator(Config());n.set_motion_feedback(0,0,0)
  self.assertEqual(n.step((0,0,0),scan([(.20,-1,.3,1)]),0,.05),(0.,0.))
  self.assertEqual(n.state,'FOOTPRINT_BLOCKED')
 def test_pause_requires_new_settle(self):
  n=PotentialNavigator(Config());n.phase='DRIVE';n.pause()
  n.set_motion_feedback(0,0,0)
  self.assertEqual(n.step((0,0,0),scan(),0,.05),(0.,0.))
  self.assertEqual(n.phase,'BRAKE')
if __name__=='__main__':unittest.main()
