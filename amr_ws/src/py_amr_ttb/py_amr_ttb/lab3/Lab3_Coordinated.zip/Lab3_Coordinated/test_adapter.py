import sys,unittest,csv,tempfile,math
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,str(Path(__file__).resolve().parent/'validation'))
import ros_test_support as support
# Reuse only the transport doubles; old immediate-start expectations intentionally
# do not apply to the new measured-settle contract.
class Adapter(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  support.NodeTests.setUpClass();cls.module=support.NodeTests.module
 def setUp(self):
  support.NodeTests.setUp(self)
 def msg(self,speed=0):
  m=support.odom();m.twist=NS(twist=NS(linear=NS(x=speed,y=0.),angular=NS(z=0.)))
  return m
 def test_feedback_is_measured_not_commanded(self):
  self.node.odom_callback(self.msg(.12))
  self.assertEqual(self.node.nav.feedback,(.12,0.,10.))
 def test_invalid_twist_blocks_odom(self):
  self.node.odom_callback(self.msg(math.nan))
  self.assertIsNone(self.node.odom_received)
 def test_full_adapter_waits_then_drives_and_csv_matches(self):
  with tempfile.TemporaryDirectory() as folder:
   support.FakeNode.overrides={'log_dir':folder}
   self.node=self.module.Lab3Controller()
   for i in range(30):
    self.clock_mock.return_value=10+i*.05
    self.node.odom_callback(self.msg())
    self.node.scan_callback(support.laser())
    self.node.tick()
    if i<6:self.assertEqual(self.node.outputs[self.node.cmd_topic][-1].linear.x,0.)
   self.assertGreater(self.node.outputs[self.node.cmd_topic][-1].linear.x,0.)
   self.node.log_file.flush()
   with next(Path(folder).glob('*.csv')).open() as f:rows=list(csv.reader(f))
   self.assertTrue(all(len(r)==len(rows[0]) for r in rows))
   self.assertIn('measured_speed_m_s',rows[0])
   self.node.log_file.close()
if __name__=='__main__':unittest.main()
