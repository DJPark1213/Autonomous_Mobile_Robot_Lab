from pathlib import Path
import sys, math, json
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent/'validation'))
from py_amr_ttb.lab3.core import Config,process_scan,wrap
from py_amr_ttb.lab3.potential import PotentialNavigator
from py_amr_ttb.lab3.simulate import raycast,clearance
scenarios={}
for width in [.46,.60,.80]:
    boxes=[(-.6,-width/2-.05,1.35,-width/2),(-.6,width/2,1.3-width,1.7),(1.3,-width/2,1.35,1.7),(-.65,-width/2,-.6,width/2),(1.3-width,1.65,1.3,1.7)]
    for sign in [1,-1]:
        b=boxes if sign==1 else [(a,-d,c,-b) for a,b,c,d in boxes]
        scenarios[f'corner_{width}_{sign}']=(b,(1.3-width/2,sign*1.3))
scenarios['straight']=([(-.6,.23,2,.28),(-.6,-.28,2,-.23)],(1.5,0))
scenarios['box']=([(.65,-.2,1.,.2)],(1.5,0))
records=[];tracks={}
for name,(boxes,goal) in scenarios.items():
 for vmax in [.10,.18]:
  for seed in [0,1]:
    cfg=Config(goal_x=goal[0],goal_y=goal[1],max_linear=vmax)
    nav=PotentialNavigator(cfg);pose=np.zeros(3);vel=np.zeros(2);rng=np.random.default_rng(seed)
    scan=None;rows=[];minimum=math.inf;dt=.05
    for tick in range(1600):
        t=tick*dt
        if tick%2==0:
            r,amin,inc=raycast(pose,boxes)
            if seed:r+=rng.normal(0,.002,len(r))
            scan=process_scan(r,amin,inc,.05,12.)
        nav.set_motion_feedback(vel[0],vel[1],t)
        v,w=nav.step(pose,scan,t,dt)
        # First order motor response, with bounded acceleration/deceleration.
        dv=np.clip((v-vel[0])*dt/.18,-.5*dt,.3*dt)
        dw=np.clip((w-vel[1])*dt/.15,-2.*dt,2.*dt)
        vel+=np.array([dv,dw]);mid=pose[2]+vel[1]*dt/2
        pose+=np.array([vel[0]*math.cos(mid)*dt,vel[0]*math.sin(mid)*dt,vel[1]*dt]);pose[2]=wrap(pose[2])
        minimum=min(minimum,clearance(pose,boxes)-cfg.robot_radius)
        rows.append([t,*pose,v,w,nav.state])
        if nav.done or nav.failure:break
    rec=dict(scenario=name,speed=vmax,seed=seed,reached=nav.done,state=nav.state,time=t,clearance=minimum,brake_entries=sum(r[6]=='BRAKE_PATH_BLOCKED' for r in rows))
    records.append(rec);print(rec,flush=True)
    if seed==0:tracks[name+'_'+str(vmax)]=rows
root=Path(__file__).resolve().parent
(root/'results.json').write_text(json.dumps(records,indent=2))
(root/'tracks.json').write_text(json.dumps(tracks))
(root/'geometry.json').write_text(json.dumps(scenarios))
